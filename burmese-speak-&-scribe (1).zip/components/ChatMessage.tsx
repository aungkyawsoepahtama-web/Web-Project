import React, { useState } from 'react';
import { Message } from '../types';
import { Copy, Check, User, Bot } from 'lucide-react';

interface ChatMessageProps {
  message: Message;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const [copied, setCopied] = useState(false);
  const isUser = message.role === 'user';

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy", err);
    }
  };

  return (
    <div className={`flex w-full mb-6 ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div 
        className={`relative max-w-[85%] md:max-w-[75%] rounded-2xl p-4 md:p-6 shadow-sm
          ${isUser 
            ? 'bg-blue-600 text-white rounded-br-none' 
            : 'bg-white border border-slate-200 text-slate-800 rounded-bl-none'
          }
        `}
      >
        {/* Header with Icon and Label */}
        <div className={`flex items-center gap-2 mb-2 text-xs font-semibold opacity-80 uppercase tracking-wider
            ${isUser ? 'text-blue-100 flex-row-reverse' : 'text-slate-500'}
        `}>
           {isUser ? <User size={14} /> : <Bot size={14} />}
           <span>{isUser ? 'You' : 'Gemini'}</span>
        </div>

        {/* Content */}
        <p className="font-burmese text-lg leading-relaxed whitespace-pre-wrap">
          {message.text}
        </p>
        
        {/* Actions */}
        {message.text.trim().length > 0 && (
          <div className={`mt-3 flex ${isUser ? 'justify-start' : 'justify-end'}`}>
            <button
              onClick={handleCopy}
              className={`flex items-center gap-1.5 text-xs font-medium py-1.5 px-3 rounded-full transition-all
                ${isUser 
                  ? 'bg-blue-700 hover:bg-blue-800 text-blue-100' 
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }
              `}
            >
              {copied ? <Check size={14} /> : <Copy size={14} />}
              {copied ? 'Copied' : 'Copy Text'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
