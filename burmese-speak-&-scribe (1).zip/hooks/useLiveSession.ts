import { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { ConnectionState, Message, AppMode, Language } from '../types';
import { createBlob, decodeAudioData, base64ToArrayBuffer } from '../utils/audioUtils';

// Constants
const MODEL_NAME = 'gemini-2.5-flash-native-audio-preview-09-2025';
const SAMPLE_RATE_INPUT = 16000;
const SAMPLE_RATE_OUTPUT = 24000;

export const useLiveSession = (apiKey: string) => {
  const [status, setStatus] = useState<ConnectionState>(ConnectionState.DISCONNECTED);
  const [messages, setMessages] = useState<Message[]>([]);
  const [volume, setVolume] = useState<number>(0);
  
  // Refs for managing audio context and session
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const inputContextRef = useRef<AudioContext | null>(null);
  const outputContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Refs for text accumulation
  const currentInputTransRef = useRef<string>('');
  const currentOutputTransRef = useRef<string>('');

  const disconnect = useCallback(() => {
    // 1. Close session if possible (there isn't a direct close on the promise, but we stop sending)
    // In the real SDK, we'd call session.close() if we had the resolved object stored, 
    // but the guide implies we mostly interact via the promise for sending. 
    // We will assume closing the stream effectively ends our participation.
    
    // 2. Stop Microphone
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }

    // 3. Close Audio Contexts
    if (inputContextRef.current) {
      inputContextRef.current.close();
      inputContextRef.current = null;
    }
    if (outputContextRef.current) {
      outputContextRef.current.close();
      outputContextRef.current = null;
    }

    // 4. Stop any playing audio
    sourcesRef.current.forEach(source => source.stop());
    sourcesRef.current.clear();

    // 5. Reset State
    sessionPromiseRef.current = null;
    nextStartTimeRef.current = 0;
    setStatus(ConnectionState.DISCONNECTED);
    setVolume(0);
  }, []);

  const connect = useCallback(async (mode: AppMode, language: Language) => {
    try {
      setStatus(ConnectionState.CONNECTING);

      // Initialize Audio Contexts
      const InputContextClass = (window.AudioContext || (window as any).webkitAudioContext);
      const inputCtx = new InputContextClass({ sampleRate: SAMPLE_RATE_INPUT });
      const outputCtx = new InputContextClass({ sampleRate: SAMPLE_RATE_OUTPUT });
      
      inputContextRef.current = inputCtx;
      outputContextRef.current = outputCtx;

      // Get Microphone Stream
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      // Initialize Gemini Client
      const ai = new GoogleGenAI({ apiKey });

      // Determine System Instruction based on Mode and Language
      let systemInstruction = "";
      
      if (language === 'burmese') {
        systemInstruction = mode === AppMode.DICTATION 
          ? "You are a precise transcriber. Your ONLY task is to listen to the Burmese audio and transcribe it EXACTLY as written into Burmese text. Do NOT add any conversational filler. Do NOT reply to questions. Just output the transcription."
          : "You are a helpful and friendly AI assistant. You speak and write fluent Burmese (Myanmar). Even if the user speaks English, you should generally reply in Burmese unless asked otherwise. Keep your responses concise and helpful.";
      } else {
        systemInstruction = mode === AppMode.DICTATION 
          ? "You are a precise transcriber. Your ONLY task is to listen to the English audio and transcribe it EXACTLY as written into English text. Do NOT add any conversational filler. Do NOT reply to questions. Just output the transcription."
          : "You are a helpful and friendly AI assistant. You speak and write fluent English. Keep your responses concise and helpful.";
      }

      // Connect to Live API
      const sessionPromise = ai.live.connect({
        model: MODEL_NAME,
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          systemInstruction: systemInstruction,
        },
        callbacks: {
          onopen: () => {
            console.log('Session opened');
            setStatus(ConnectionState.CONNECTED);
            
            // Setup Audio Processing pipeline
            const source = inputCtx.createMediaStreamSource(stream);
            const processor = inputCtx.createScriptProcessor(4096, 1, 1);
            
            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              
              // Calculate volume for visualizer
              let sum = 0;
              for(let i = 0; i < inputData.length; i++) {
                sum += inputData[i] * inputData[i];
              }
              const rms = Math.sqrt(sum / inputData.length);
              setVolume(Math.min(1, rms * 5)); // Amplify a bit for visual

              // Send to API
              const pcmBlob = createBlob(inputData);
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };

            source.connect(processor);
            processor.connect(inputCtx.destination);
            
            sourceRef.current = source;
            processorRef.current = processor;
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Transcription
            let hasUpdate = false;
            
            if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              if (text) {
                 currentInputTransRef.current += text;
                 hasUpdate = true;
              }
            }
            
            if (message.serverContent?.outputTranscription) {
               const text = message.serverContent.outputTranscription.text;
               if (text) {
                 currentOutputTransRef.current += text;
                 hasUpdate = true;
               }
            }

            if (hasUpdate) {
               // Update the "pending" message in the UI or add to list
               setMessages(prev => {
                 const newMessages = [...prev];
                 
                 // Handle User Message (Input)
                 if (currentInputTransRef.current.trim()) {
                   // Find last active user message manually (replacement for findLastIndex)
                   let lastUserIdx = -1;
                   for (let i = newMessages.length - 1; i >= 0; i--) {
                     if (newMessages[i].role === 'user' && !newMessages[i].isComplete) {
                       lastUserIdx = i;
                       break;
                     }
                   }

                   if (lastUserIdx >= 0) {
                     newMessages[lastUserIdx].text = currentInputTransRef.current;
                   } else {
                     newMessages.push({
                       id: Date.now().toString() + '-user',
                       role: 'user',
                       text: currentInputTransRef.current,
                       isComplete: false,
                       timestamp: Date.now(),
                     });
                   }
                 }

                 // Handle Assistant Message (Output)
                 if (currentOutputTransRef.current.trim()) {
                   // Find last active assistant message manually (replacement for findLastIndex)
                   let lastBotIdx = -1;
                   for (let i = newMessages.length - 1; i >= 0; i--) {
                     if (newMessages[i].role === 'assistant' && !newMessages[i].isComplete) {
                       lastBotIdx = i;
                       break;
                     }
                   }

                   if (lastBotIdx >= 0) {
                      newMessages[lastBotIdx].text = currentOutputTransRef.current;
                   } else {
                      newMessages.push({
                        id: Date.now().toString() + '-ai',
                        role: 'assistant',
                        text: currentOutputTransRef.current,
                        isComplete: false,
                        timestamp: Date.now(),
                      });
                   }
                 }
                 return newMessages;
               });
            }

            if (message.serverContent?.turnComplete) {
              // Mark messages as complete
              setMessages(prev => prev.map(m => ({ ...m, isComplete: true })));
              currentInputTransRef.current = '';
              currentOutputTransRef.current = '';
            }

            // Handle Audio Output
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio && outputContextRef.current) {
              const ctx = outputContextRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              
              const audioData = new Uint8Array(base64ToArrayBuffer(base64Audio));
              const audioBuffer = await decodeAudioData(audioData, ctx, SAMPLE_RATE_OUTPUT, 1);
              
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              const gainNode = ctx.createGain(); // Use gain for potential volume control
              source.connect(gainNode);
              gainNode.connect(ctx.destination);
              
              source.onended = () => {
                sourcesRef.current.delete(source);
              };
              
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
            }
          },
          onclose: () => {
            console.log('Session closed');
            setStatus(ConnectionState.DISCONNECTED);
          },
          onerror: (err) => {
            console.error('Session error', err);
            setStatus(ConnectionState.ERROR);
            disconnect();
          }
        }
      });

      sessionPromiseRef.current = sessionPromise;

    } catch (error) {
      console.error("Failed to connect:", error);
      setStatus(ConnectionState.ERROR);
      disconnect();
    }
  }, [apiKey, disconnect]);

  const clearMessages = useCallback(() => {
    setMessages([]);
    currentInputTransRef.current = '';
    currentOutputTransRef.current = '';
  }, []);

  return {
    status,
    connect,
    disconnect,
    volume,
    messages,
    clearMessages
  };
};